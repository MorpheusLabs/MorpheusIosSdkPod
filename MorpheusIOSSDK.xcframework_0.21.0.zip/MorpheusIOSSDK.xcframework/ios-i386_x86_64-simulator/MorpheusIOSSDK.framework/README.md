# MorpheusIOS swift SDK


### Docs

### Install Dependencies 
For install carthage please used commend 
"carthage update --no-use-binaries --platform iOS"

Remember use last version carhage

Discripton how update framework to pod: (Polish)

1. Otwórz repozytorium z SDK https://github.com/MorpheusLabs/MorpheusIosSDK
2. Ustawa Edit Sheme Na MorpheusIOSSDK-Universal
3. Dla targetu MorpheusIOSSDK w General podbij wersje np. z  0.17.0 na 0.18.0 
4. Dla targetu MorpheusIOSSDK-Universal w Build Settings Dla pola Marketing Version podbij wersje np. z  0.17.0 na 0.18.0 
5. Uruchom plik MorpheusIOSSDK.podspec podbij wersje np.
    s.version          = '0.17.0’
    na 
    s.version          = '0.18.0'
6. Uruchom projekt X+R na MorpheusIOSSDK-Universal - to wygeneruj pliki na twój pulpit :
    - MorpheusIOSSDK_0.xx.0 - spakowana lib
    - docs_0.xx.0  - dokumentacja
7. Wgraj lib MorpheusIOSSDK_0.xx.0 na sdk  https://github.com/MorpheusLabs/MorpheusIosSdkPod
    pod commitem  na branch mastera
8. Uruchom termina i wjedz do katalogu frameworka MorpheusIOSSDK
9. Sprawdź czy prawnie generuje sie pod komendą :
    pod spec lint --verbose
10. Zarejestruj swoje konto jeśli potrzeba w repo Cocapods  np:
    $ pod trunk register orta@cocoapods.org 'Orta Therox' --description='macbook air'
    np. $ pod trunk register ik13jack@gmail.com 'iK13Jack' --description='macbook pro'
    https://guides.cocoapods.org/making/getting-setup-with-trunk.html
11. Wyślij framework do cocoa:
    pod  trunk push
12. Wgrany pod jest pod linkiem :  https://cocoapods.org/pods/MorpheusIOSSDK
    Updating spec repo `trunk`

--------------------------------------------------------------------------------
 🎉  Congrats
 🚀  MorpheusIOSSDK (0.18.0) successfully published
 📅  April 25th, 23:50
 🌎  https://cocoapods.org/pods/MorpheusIOSSDK
 👍  Tell your friends!
--------------------------------------------------------------------------------

13. Uaktalnij swój projekt gdzie używasz framweroka  MorpheushIOSSDK (pod init) w projekcje : 
    - pod repo update
    - pod install

Link:
- https://www.youtube.com/watch?v=oZSZ8mievUU
- https://guides.cocoapods.org/making/getting-setup-with-trunk.html
https://www.raywenderlich.com/5823-how-to-create-a-cocoapod-in-swift
- https://www.raywenderlich.com/7076593-cocoapods-tutorial-for-swift-getting-started

xcodebuild archive   -scheme MorpheusIOSSDK   -sdk iphonesimulator   -archivePath "archives/ios_simulators.xcarchive"   BUILD_LIBRARY_FOR_DISTRIBUTION=YES SKIP_INSTALL=NO
