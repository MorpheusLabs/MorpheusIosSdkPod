//
//  MorpheusIOSSDK.h
//  MorpheusIOSSDK
//
//  Created by Jacek Kurbiel on 19/02/2020.
//  Copyright © 2020 Jacek Kurbiel. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MorpheusIOSSDK.
FOUNDATION_EXPORT double MorpheusIOSSDKVersionNumber;

//! Project version string for MorpheusIOSSDK.
FOUNDATION_EXPORT const unsigned char MorpheusIOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MorpheusIOSSDK/PublicHeader.h>


